DATA_FILE = "niveles.json"
BOT_VERSION = "4.2"

RANGOS = {
    1: "🌱 Mortal Errante",
    5: "🛡️ Guerrero del Ágora",
    10: "🔥 Héroe Forjado por Hefesto",
    15: "🦉 Discípulo de Atenea",
    20: "⚡ Semidiós del Olimpo",
    30: "🌌 Elegido de los Titanes",
    40: "👑 Dios del Olimpo",
}

STAFF_ROLE_ID = 1339567560047198328
CATEGORY_NAME = "📂 Oráculos"
OWNER_ID = 443479189597716480
LOG_CHANNEL_ID = 1425811285538242691
