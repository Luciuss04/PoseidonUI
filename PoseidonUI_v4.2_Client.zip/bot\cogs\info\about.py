import discord
from discord import app_commands
from discord.ext import commands

from bot.config import OWNER_ID, BOT_VERSION


class About(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(
        name="plan", description="Muestra información sobre tu plan y licencia actual"
    )
    async def plan(self, interaction: discord.Interaction):
        try:
            # Recuperar info del bot
            plan = getattr(self.bot, "active_plan", "Unknown")
            key = getattr(self.bot, "license_key", "Unknown")
            is_trial = getattr(self.bot, "is_trial", False)
            
            # Formatear Plan
            plan_emojis = {
                "basic": "🥉 Básico",
                "pro": "🥈 Pro",
                "elite": "🥇 Élite",
                "custom": "👑 Custom"
            }
            plan_display = plan_emojis.get(plan, f"❓ {plan.capitalize()}")
            if is_trial:
                plan_display += " (Trial / Prueba)"

            # Enmascarar Licencia
            if key and len(key) > 10:
                masked_key = f"{key[:9]}****-****-{key[-4:]}"
            else:
                masked_key = "NO-LICENSE"

            embed = discord.Embed(
                title="📋 Panel de Cliente",
                description="Información de tu suscripción y versión del sistema.",
                color=discord.Color.blue()
            )
            
            embed.add_field(name="🤖 Versión del Bot", value=f"`v{BOT_VERSION}`", inline=True)
            embed.add_field(name="📦 Plan Activo", value=f"**{plan_display}**", inline=True)
            embed.add_field(name="🔑 Licencia", value=f"`{masked_key}`", inline=False)
            
            # Estado
            status = "✅ Activo" if plan else "❌ Inactivo"
            embed.add_field(name="Estado del Servicio", value=status, inline=True)
            
            # Footer
            embed.set_footer(text=f"ID Servidor: {interaction.guild.id}")
            
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Error al obtener info del plan: {e}", ephemeral=True)

    @app_commands.command(
        name="info", description="Resumen de funciones y módulos disponibles"
    )
    async def info(self, interaction: discord.Interaction):
        try:
            print(f"DEBUG: /info triggered by {interaction.user}")
            features = (
                "⚡ **Oráculo**: Canales de ayuda y tickets"
                "\n🛡 **Guardian**: Verificación y seguridad"
                "\n🌟 **Niveles**: XP, rangos y recompensas"
                "\n🐶 **Mascotas**: Crianza, evoluciones y duelos"
                "\n🏛️ **Clanes**: Olimpos, guerras y ranking global"
                "\n💍 **Social**: Matrimonios, familia y ship"
                "\n💰 **Economía**: Global, tiendas y apuestas"
                "\n🏆 **LoL**: Estadísticas en tiempo real"
                "\n📊 **Status**: Diagnóstico del sistema"
            )
            embed = discord.Embed(
                title=f"🌊 PoseidonUI v{BOT_VERSION}", description=features, color=discord.Color.teal()
            )
            banner_url = "https://raw.githubusercontent.com/Luciuss04/PoseidonUI/main/BotDiscord4.0/banner.png"
            embed.set_image(url=banner_url)
            embed.add_field(name="Versión", value=f"{BOT_VERSION} (Stable)", inline=True)
            embed.add_field(
                name="Comandos Clave",
                value="`/ayuda` `/clan` `/mascota` `/love` `/top`",
                inline=False,
            )
            embed.add_field(name="Desarrollador", value="Luciuss04", inline=True)
            embed.set_footer(text="El poder del Olimpo en tu servidor.")
            await interaction.response.send_message(embed=embed, view=BuyView(self.bot))
        except Exception as e:
            import traceback
            traceback.print_exc()
            await interaction.response.send_message(f"❌ Error interno: {e}", ephemeral=True)

    @app_commands.command(
        name="novedades", description="Muestra las últimas novedades y actualizaciones del bot"
    )
    async def novedades(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="✨ Novedades de PoseidonUI",
            description="¡El Olimpo se renueva! Aquí tienes las últimas mejoras implementadas:",
            color=discord.Color.gold()
        )
        if self.bot.user.avatar:
            embed.set_thumbnail(url=self.bot.user.avatar.url)
        
        embed.add_field(
            name="💰 Economía Divina", 
            value="• **`/transfer`**: ¡Envía monedas a otros usuarios!\n• **`/slots`**: ¡Prueba tu suerte en las tragaperras divinas!",
            inline=False
        )
        embed.add_field(
            name="🛠️ Diagnóstico y Estabilidad",
            value="• **`!status`**: Comando de prefijo rápido para verificar estado.\n• **`/status`**: Arreglado y optimizado para admins/staff.\n• **Logs**: Mejoras en el sistema de reporte de errores.",
            inline=False
        )
        embed.add_field(
            name="👥 Comunidad y Diversión",
            value="• **`/userinfo` y `/serverinfo`**: Información detallada al instante.\n• **`/8ball`**: ¡Pregúntale al oráculo mágico!\n• **`/ship`**: Calculadora de amor.\n• **`/hack`**: Simulación divertida.\n• **`/dado` y `/moneda`**: Azar básico.\n• **Sugerencias**: Sistema optimizado para feedback.",
            inline=False
        )
        
        import datetime
        fecha = datetime.datetime.utcnow().strftime('%d/%m/%Y')
        embed.set_footer(text=f"Versión {BOT_VERSION} • {fecha}")
        await interaction.response.send_message(embed=embed)


    @app_commands.command(
        name="admin_panel", description="[OWNER] Panel de administración de clientes (Local/Remoto)"
    )
    async def admin_panel(self, interaction: discord.Interaction, modo: str = "local"):
        """
        modo: 'local' (lee archivo json) o 'remoto' (escanea canal de status)
        """
        if interaction.user.id != OWNER_ID:
            await interaction.response.send_message("❌ Acceso denegado.", ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)

        clients = {}

        # MODO REMOTO: Escanear canal de reportes
        if modo.lower() == "remoto":
            import os
            import aiohttp
            
            status_channel_id = os.getenv("STATUS_CHANNEL_ID")
            webhook_url = os.getenv("STATUS_WEBHOOK_URL")

            # Intentar deducir Channel ID del Webhook si falta
            if not status_channel_id and webhook_url:
                try:
                    async with aiohttp.ClientSession() as session:
                        webhook = discord.Webhook.from_url(webhook_url, session=session)
                        fetched_webhook = await webhook.fetch()
                        status_channel_id = fetched_webhook.channel_id
                except Exception as e:
                    print(f"Error fetching webhook channel: {e}")

            if not status_channel_id:
                await interaction.followup.send("⚠️ `STATUS_CHANNEL_ID` no configurado y no pude deducirlo del Webhook.")
                return
            
            try:
                channel = self.bot.get_channel(int(status_channel_id))
                if not channel:
                    try:
                        channel = await self.bot.fetch_channel(int(status_channel_id))
                    except:
                        pass
                
                if not channel:
                    await interaction.followup.send(f"❌ No pude acceder al canal {status_channel_id}. Verifica permisos.")
                    return

                await interaction.followup.send(f"📡 Escaneando últimos reportes en {channel.mention}...", ephemeral=True)
                
                # Leer últimos 50 mensajes para reconstruir estado
                async for msg in channel.history(limit=50):
                    if msg.author.bot and msg.embeds:
                        for embed in msg.embeds:
                            if embed.footer and embed.footer.text and "GID:" in embed.footer.text:
                                # Parsear footer "KEY:xxx|GID:123"
                                try:
                                    parts = embed.footer.text.split("|")
                                    gid = parts[1].replace("GID:", "")
                                    
                                    # Solo guardar el más reciente por GID
                                    if gid not in clients:
                                        # Parse fields
                                        data = {
                                            "name": "Unknown",
                                            "plan": "Unknown",
                                            "version": "?",
                                            "members": "0",
                                            "seen": msg.created_at.strftime("%Y-%m-%d %H:%M")
                                        }
                                        for field in embed.fields:
                                            if field.name == "Server": data["name"] = field.value
                                            if field.name == "Plan": data["plan"] = field.value
                                            if field.name == "Version": data["version"] = field.value
                                            if field.name == "Members": data["members"] = field.value
                                        
                                        clients[gid] = data
                                except:
                                    continue
            except Exception as e:
                await interaction.followup.send(f"❌ Error escaneando remoto: {e}")
                return

        # MODO LOCAL: Leer archivo json
        else:
            import json
            import pathlib
            reg_path = pathlib.Path("client_registry.json")
            if reg_path.exists():
                try:
                    local_data = json.loads(reg_path.read_text(encoding="utf-8"))
                    for gid, info in local_data.items():
                        clients[gid] = {
                            "name": info.get("name"),
                            "plan": info.get("plan"),
                            "version": info.get("version"),
                            "members": info.get("members"),
                            "seen": info.get("last_seen")
                        }
                except:
                    pass
        
        if not clients:
            await interaction.followup.send("⚠️ No se encontraron clientes activos.")
            return

        # Construir Embed
        embed = discord.Embed(
            title=f"👑 Panel de Clientes ({modo.upper()})",
            description=f"Total Detectados: **{len(clients)}**",
            color=discord.Color.dark_gold()
        )
        
        for gid, data in clients.items():
            status = "🟢" # Asumimos activo si está en la lista reciente
            embed.add_field(
                name=f"{status} {data['name']}",
                value=f"🆔 `{gid}`\n📦 **{data['plan']}** | 🤖 **{data['version']}**\n👥 {data['members']} | 🕒 {data['seen']}",
                inline=True
            )
            
        await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="activar", description="Activar licencia de PoseidonUI")
    async def activar(self, interaction: discord.Interaction, key: str):
        import pathlib
        import re
        from datetime import datetime

        if not re.fullmatch(r"POSEIDON-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}", key):
            await interaction.response.send_message(
                "❌ Formato inválido de licencia.", ephemeral=True
            )
            return
        lic_files = [pathlib.Path("licenses.txt"), pathlib.Path("licenses_plans.txt")]
        ok = False
        valid = set()
        for lic_file in lic_files:
            if lic_file.exists():
                lines = lic_file.read_text(encoding="utf-8").splitlines()
                for ln in lines:
                    s = ln.strip()
                    if not s or s.startswith("#"):
                        continue
                    # Si es formato KEY|PLAN|SIG o KEY|PLAN, tomamos solo la KEY
                    key_part = s.split("|")[0].strip()
                    if key_part:
                        valid.add(key_part)
        
        ok = key in valid
        if not ok:
            await interaction.response.send_message(
                "❌ Licencia no válida.", ephemeral=True
            )
            return
        guild_id = interaction.guild.id if interaction.guild else 0
        guild_name = interaction.guild.name if interaction.guild else "DM"
        bind_path = pathlib.Path("license_bindings.txt")
        bound_other = False
        if bind_path.exists():
            lines = [
                ln.strip()
                for ln in bind_path.read_text(encoding="utf-8").splitlines()
                if ln.strip() and not ln.strip().startswith("#")
            ]
            for ln in lines:
                try:
                    k, gid, *_ = ln.split("|")
                    if k == key and int(gid) != guild_id and int(gid) != 0:
                        bound_other = True
                        break
                except Exception:
                    pass
        if bound_other:
            await interaction.response.send_message(
                "❌ Esta licencia ya está activa en otro servidor.", ephemeral=True
            )
            try:
                owner = await self.bot.fetch_user(OWNER_ID)
                msg = (
                    "⚠️ Intento de activar licencia ya usada\n"
                    f"Usuario: {interaction.user} ({interaction.user.id})\n"
                    f"Servidor: {guild_name} ({guild_id})\n"
                    f"Licencia: {key}"
                )
                await owner.send(msg)
            except Exception:
                pass
            return

        pathlib.Path("license_active.txt").write_text(key, encoding="utf-8")
        entry = (
            f"{key}|{guild_id}|{guild_name}|{datetime.utcnow().isoformat()}|PERM|PERM"
        )
        bind_path.open("a", encoding="utf-8").write(entry + "\n")
        await interaction.response.send_message(
            "✅ Licencia activada y vinculada (permanente).", ephemeral=True
        )
        try:
            e = interaction.client.build_log_embed(
                "Info/Licencia",
                "Licencia activada",
                user=interaction.user,
                guild=interaction.guild,
                extra={"Clave": key, "Servidor": str(interaction.guild.id)},
            )
            await interaction.client.log(embed=e, guild=interaction.guild)
        except Exception:
            pass
        try:
            owner = await self.bot.fetch_user(OWNER_ID)
            when = datetime.utcnow().isoformat()
            msg = (
                "🔑 Activación\n"
                f"Usuario: {interaction.user} ({interaction.user.id})\n"
                f"Servidor: {guild_name} ({guild_id})\n"
                f"Licencia: {key}\n"
                f"Fecha: {when}\n"
                "Estado: PERMANENTE"
            )
            await owner.send(msg)
            pathlib.Path("activations.log").open("a", encoding="utf-8").write(
                msg + "\n"
            )
        except Exception:
            pass


class BuyView(discord.ui.View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(
        label="Comprar licencia", style=discord.ButtonStyle.success, emoji="💳"
    )
    async def buy(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="💎 Planes de Licencia PoseidonUI",
            description="Elige el poder que necesitas para tu servidor.",
            color=discord.Color.gold()
        )
        embed.add_field(
            name="🥉 Básico — 19€",
            value="• Status y Guardian\n• Licencia Permanente\n• Soporte Básico",
            inline=False
        )
        embed.add_field(
            name="🥈 Pro — 39€",
            value="• Todo lo Básico +\n• Oráculo (Tickets) y Niveles\n• Economía y Anti-Spam\n• Soporte Prioritario",
            inline=False
        )
        embed.add_field(
            name="🥇 Élite — 69€",
            value="• Todo lo Pro +\n• Ofertas, Sorteos y LoL\n• Integraciones Web\n• Soporte VIP 24/7",
            inline=False
        )
        embed.add_field(
            name="👑 Custom — 99€+",
            value="• Desarrollo a medida\n• Funciones exclusivas\n• Branding personalizado",
            inline=False
        )
        embed.set_footer(text="Para adquirir una licencia, contacta al desarrollador.")
        
        # Crear botón de contacto (link a DM o server de soporte si hubiera, aquí usamos DM simulado o mensaje)
        # Como no podemos abrir DM directo con botón sin url, enviaremos mensaje.
        
        view = discord.ui.View()
        view.add_item(discord.ui.Button(label="Contactar a Luciuss04", url=f"https://discord.com/users/{OWNER_ID}", emoji="📨"))
        
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(About(bot))
